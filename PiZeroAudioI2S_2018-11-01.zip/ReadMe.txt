Please quote for 100 units of these assembled.
The Bill of Materials is in the XML file

Note that the 2x20 Header is mounted on the bottom of the page, as shown in the images
